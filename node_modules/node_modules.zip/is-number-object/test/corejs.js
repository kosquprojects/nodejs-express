'use strict';

require('core-js');

require('./');
