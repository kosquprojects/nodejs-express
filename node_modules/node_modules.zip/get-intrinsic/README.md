# get-intrinsic
Get and robustly cache all JS language-level intrinsics at first require time.
